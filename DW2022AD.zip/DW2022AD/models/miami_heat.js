const Sequelize = require('sequelize');

const Miami_heat = (sequelize) =>{
    sequelize.define('Miami_heat',{
        nombreJugador: Sequelize.STRING,
        numeroJugador: Sequelize.INTEGER,
        puntosPorPartido: Sequelize.DOUBLE
    })
}

module.exports = Miami_heat;