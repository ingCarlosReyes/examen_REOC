const express = require('express');
const router = express.Router();
const miami_heatController= require('../controllers/miami_heat')
//Create,Read,Update,Delete  (CRUD)  Altas Bajas Cambios Consultas
//Servicio para mostrar el formulario
router.get('/altaMiami_heat',miami_heatController.getAltaMiami_heat);
//Servicio para procesar los datos del formulario
router.post('/altaMiami_heat',miami_heatController.postAltaMiami_heat);
//Servicio para consultar todos los datos
router.get('/consultaMiami_heat',miami_heatController.getMiami_heat);
//Servicio para eliminar un registro por id
router.post('/bajaMiami_heat', miami_heatController.postEliminarMiami_heat);
//Servicio para actualizar las consola
router.post('/actualizarMiami_heat',miami_heatController.postActualizarMiami_heat);

module.exports = router